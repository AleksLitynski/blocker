using UnityEngine;
using System.Collections;

public class PostGameMenu
{

	public static void generateGUI(GameObject menuManager)
	{
		
	}
}
