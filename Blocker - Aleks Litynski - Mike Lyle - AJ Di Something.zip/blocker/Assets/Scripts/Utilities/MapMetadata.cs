using UnityEngine;
using System.Collections;

public class MapMetadata : MonoBehaviour 
{
	public string description;
}
