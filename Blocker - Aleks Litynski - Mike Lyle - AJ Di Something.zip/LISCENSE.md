Don't steal my shit?
Is that what you want me to say, github?

Like, no stealing, or else!